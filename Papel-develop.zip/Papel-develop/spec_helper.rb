require 'coveralls'
Coveralls.wear!